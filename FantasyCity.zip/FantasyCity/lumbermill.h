#ifndef LUMBERMILL_H
#define LUMBERMILL_H

#include "building.h"

class LumberMill : public Building
{
public:
    LumberMill();
};

#endif // LUMBERMILL_H
