#include "getcoordinates.h"

GetCoordinates::GetCoordinates()
{

}
int GetCoordinates::getMine(int coordinate){
    m_coordinate = coordinate;


    return m_coordinate;
}
