#ifndef GETCOORDINATES_H
#define GETCOORDINATES_H


class GetCoordinates
{
    int m_coordinate = 0;
public:
    GetCoordinates();

      int getMine(int coordinate);
};

#endif // GETCOORDINATES_H
